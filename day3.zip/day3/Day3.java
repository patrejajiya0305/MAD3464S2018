/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day3;

/**
 *
 * @author Jia Patreja
 */
public class Day3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Person hitesh = new Person();
        hitesh.name = "Hiteshwar";
        hitesh.address = "Mississauga";
        hitesh.gender = 'M';
        hitesh.age = 22;
        hitesh.phoneNo = "416-828-0869";
        
        System.out.println("Name:" + hitesh.name);
        System.out.println("Address:" + hitesh.address);
        System.out.println("Gender:" + hitesh.gender);
        System.out.println("Age:" + hitesh.age);
        System.out.println("PhoneNo:" + hitesh.phoneNo);
        /*
        Person Shashank = new Person();
        Shashank.setName();
        System.out.println("Name : " + Shashank.getName());
        Shashank.setAddress();
        System.out.println("Address : " + Shashank.getAddress());
        Shashank.setPhoneNo();
        System.out.println("PhoneNo : " + Shashank.getPhoneNo());
        Shashank.setGender();
        System.out.println("Gender : " + Shashank.getGender());
        Shashank.setAge();
        System.out.println("Age : " + Shashank.getAge());
        
           
        System.out.println(Shashank.toString());
        */
        Person Saloni = new Person();
        Saloni.setData();
        System.out.println(Saloni.toString());
               
    }
}
        
                
                
        
        
        // TODO code application logic here
  
