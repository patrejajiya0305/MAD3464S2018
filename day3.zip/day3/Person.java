/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day3;

import java.util.Scanner;

/**
 *
 * @author Jia Patreja
 */
public class Person {
    String name;
    String address;
    String phoneNo;
    int age;
    char gender;
    
    Scanner in = new Scanner(System.in);
    
    void setName(){
        
        System.out.println("Enter Name");
        name = in.nextLine();
    }
    String getName(){
        return name;
    }
    void setAddress(){
        
        System.out.println("Enter address : ");
        address = in.nextLine();
    }
    String getAddress(){
        return address;
    }
    void setGender(){
        System.out.println("Enter Gender : ");
        gender = (char) in.nextInt();
        in.nextLine();
        
    }
    char getGender(){
        return gender;
        
    }
     void setAge(){
         System.out.println("Enter age : ");
         //age = in.nextInt();
         //age = in.nextLine();
         age = Integer.parseInt(in.nextLine());
         in.nextLine();
     }  
     int getAge(){
         return age;
     }
    void setPhoneNo(){
        System.out.println("Enter PhoneNo : ");
        phoneNo=in.nextLine();
    }
    String getPhoneNo(){
        return phoneNo;
    }
    @Override
    public String toString(){
        String data = "Name : "+ name +"\n" +
                "Address : " + address + "\n" +
                "PhoneNo " + phoneNo + "\n" +
                 "Age : " + age + "\n" +
                  "Gender : " + gender + "\n" ;
                return data;
    }
    void setData(){
        setName();
        setAddress();
        setPhoneNo();
        setAge();
        setGender();
    }

    

}