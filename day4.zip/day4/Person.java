/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4;

import java.util.Scanner;

/**
 *
 * @author Jia Patreja
 */
class Person {
     String name;
    String address;
    String phoneNo;
    int age;
    char gender;
    
    Scanner in = new Scanner(System.in); 
    
    //default constructor
    
    Person(){
        name = "Unknown";
        address = "Unknown";
        phoneNo = "Unknown";
        age =1;
        gender = 'U';
    }
    //parametrized constructor
    Person(String name, String address, String phoneNo,char gender,int age){
        
        this.name = name;
        this.address = address;
        this.phoneNo = phoneNo;
        this.gender = gender;
        this.age = age;
    }
    //copy constructor
    Person(Person anotherPerson)
    {
        this.name = anotherPerson.name;// keyword this rep the object using which you are calling the method
        this.address = anotherPerson.address;
        this.age = anotherPerson.age;
        this.phoneNo = anotherPerson.phoneNo;
        this.gender = anotherPerson.gender;
    }
     
     
    
    void setName(){
        
        System.out.println("Enter Name");
        name = in.nextLine();
    }
    String getName(){
        return name;
    }
    void setAddress(){
        
        System.out.println("Enter address : ");
        address = in.nextLine();
    }
    String getAddress(){
        return address;
    }
    void setGender(){
        System.out.println("Enter Gender : ");
        gender = (char) in.nextInt();
        in.nextLine();
        
    }
    char getGender(){
        return gender;
        
    }
     void setAge(){
         System.out.println("Enter age : ");
         //age = in.nextInt();
         //age = in.nextLine();
         age = Integer.parseInt(in.nextLine());
         in.nextLine();
     }  
     int getAge(){
         return age;
     }
    void setPhoneNo(){
        System.out.println("Enter PhoneNo : ");
        phoneNo=in.nextLine();
    }
    String getPhoneNo(){
        return phoneNo;
    }
    @Override
    public String toString(){
        String data = "Name : "+ name +"\n" +
                "Address : " + address + "\n" +
                "PhoneNo " + phoneNo + "\n" +
                 "Age : " + age + "\n" +
                  "Gender : " + gender + "\n" ;
                return data;
    }
    void setData(){
        setName();
        setAddress();
        setPhoneNo();
        setAge();
        setGender();
    }

    
}
