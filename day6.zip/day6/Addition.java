/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day6;

/**
 *
 * @author Jia Patreja
 */
public class Addition implements arithmetic,multiplication {

    @Override
    public void display() {
        // n1=10; cannot initialise this here as class is implementing some other class
        // n2 =20;
        System.out.println("Addition :" + (n1+n2));
    
    
    }
    public void multiplication() {
    System.out.println("Multiplication : "+(n1*n2));
    
    }   
}
