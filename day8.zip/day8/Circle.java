/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day8;

/**
 *
 * @author Jia Patreja
 */
public class Circle extends Shape {
    //if u want to create any abstract method in the class which has been been inherited 
    
    Circle(int x,int y)
    {
        super(x,y);
    }
    
    @Override
    void draw()
    {
        //super.x = 10;
        //super.y = 20;
        //System.out.println(" x:" + super.x);
        //System.out.println(" x:" + super.y);
        
        System.out.println("Drawing Circle at" + super.x + "and" + super.y);
        //if we want to to create abstarct method we need to declare class as abstract
        
    }
    
    //abstract void animate();
    //partial abstraction
    
    
}
