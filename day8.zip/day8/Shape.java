/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day8;

/**
 *
 * @author Jia Patreja
 */
abstract class Shape {
    
    
                int x;
                int y;
                final int z = 0; //fixed value of variable
                Shape(int x, int y){
                    this.x = x;
                    this.y = y;
                    
                }
               
                
                
                void display(){
                    System.out.println("This is to display shape");
                }
                abstract void draw();
        
                
                
        }
        // TODO code application logic here
    
    

