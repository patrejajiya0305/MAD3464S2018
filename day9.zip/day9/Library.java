/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day9;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Jia Patreja
 */
public class Library {
    public static void main(String args[]){
        ArrayList<String> bookId = new ArrayList<String>();
        
        bookId.add("B001");
        bookId.add("B002");
        
        for(String str1 : bookId){
            System.out.println(str1);
        }
        bookId.add(1,"B005");
        
        
        for (String str1 : bookId){
            System.out.println(str1);
        }
        if (bookId.contains("B005")){
            System.out.println("we have a book");
        bookId.remove("B005");  //to remove
        
        }
        else {
            
            System.out.println("Book Unavailable");
            
        }
        for(String str1 : bookId){
            System.out.println(str1);
        }
        
        ArrayList<Books> library  = new ArrayList<Books> ();
        //new array list contains whole librar- every info related to books
        Books Book1 = new Books(1, "Java",2);
                
                Books Book2 = new Books(2, "Java",5 );
                Books Book3 = new Books(3, "Android",7);
                Books Book4 = new Books(4, "Swift",4);
                
                
                library.add(Book1);
                library.add(Book2);
                library.add(Book3);
                library.add(Book4);
                
                library.add(2,new Books(10,"Database",9));//adding another book at specific location
                
                for(Books book : library){
                    book.displayInfo();
                }
                
                System.out.println("Number of books in the library :--->+library.size()");
                        
                
                if(library.contains(Book4)){
                    library.remove(Book4);
    }
                System.out.println("Number of books in the library : " + 
                library.size());
//        
//        for(Books book : library){
//            book.displayInfo();
//        }
        
        Collections.sort(library,new bookRatingComparator());
       
        library.forEach( bk -> {
            bk.displayInfo();
        });
        
        Collections.sort(library, new bookTitleComparator());
        for (Books bk: library){
            //bk.displayInfo();
        }
    }
}

                
                
        
        
        
    
    
    

